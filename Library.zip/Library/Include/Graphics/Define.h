#ifndef U22_GRAPHICS_DEFINE_H
#define U22_GRAPHICS_DEFINE_H


namespace u22::graphics {
enum class EffectShaderType {
    Sprite,
    LineCircle,
    LineRectangle
};
}
#endif // !U22_GRAPHICS_DEFINE_H