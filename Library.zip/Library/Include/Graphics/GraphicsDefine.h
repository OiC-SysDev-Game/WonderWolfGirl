#ifndef U22_GRAPHICS_GRAPHICS_DEFINE_H
#define U22_GRAPHICS_GRAPHICS_DEFINE_H


namespace u22::graphics {
enum class EffectShaderType {
    Sprite,
    Circle,
    Rectangle
};
}
#endif // !U22_GRAPHICS_GRAPHICS_DEFINE_H