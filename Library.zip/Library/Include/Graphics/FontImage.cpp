#include "FontImage.h"


u22::graphics::FontImage::FontImage() :
    offset_x(),
    offset_y(),
    width(),
    height(),
    pixels() {
}

u22::graphics::FontImage::~FontImage() {
}