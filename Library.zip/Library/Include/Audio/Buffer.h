//#ifndef U22_AUDIO_BUFFER_H
//#define U22_AUDIO_BUFFER_H
//
//
//#include "../Common/Common.h"
//
//
//namespace u22::audio {
//class Buffer {
//private:
//public:
//    /// <summary>
//    /// �R���X�g���N�^
//    /// </summary>
//    Buffer();
//    /// <summary>
//    /// �f�X�g���N�^
//    /// </summary>
//    ~Buffer();
//    /// <summary>
//    /// ����
//    /// </summary>
//    /// <param name="type">���</param>
//    /// <param name="size">�T�C�Y</param>
//    /// <param name="data">�f�[�^</param>
//    /// <returns>����</returns>
//    bool Generate(int type, int size, const void* data);
//    /// <summary>
//    /// �폜
//    /// </summary>
//    /// <param name=""></param>
//    void Delete(void);
//};
//}
//#endif // !U22_AUDIO_BUFFER_H