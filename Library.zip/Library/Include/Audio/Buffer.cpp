//#include "Buffer.h"
//
//
//u22::audio::Buffer::Buffer() {
//}
//
//u22::audio::Buffer::~Buffer() {
//}
//
//bool u22::audio::Buffer::Generate(int type, int size, const void* data) {
//    return true;
//}
//
//void u22::audio::Buffer::Delete() {
//}